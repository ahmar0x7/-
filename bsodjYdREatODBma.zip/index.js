const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const sharp = require('sharp');
const AdmZip = require('adm-zip');
const cors = require('cors');
const { spawn } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Ensure directories exist
const ensureDirectories = async () => {
    await fs.ensureDir('./uploads');
    await fs.ensureDir('./temp');
    await fs.ensureDir('./output');
};

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 50 * 1024 * 1024 // 50MB limit
    }
});

// Helper function to format file size
const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 بايت';
    const k = 1024;
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// Helper function to get file stats
const getFileStats = async (filePath) => {
    const stats = await fs.stat(filePath);
    return {
        size: stats.size,
        created: stats.birthtime,
        modified: stats.mtime
    };
};

// Compression function for images
const compressImage = async (inputPath, outputPath, quality = 80) => {
    try {
        const image = sharp(inputPath);
        const metadata = await image.metadata();
        
        // Compress based on format
        if (metadata.format === 'jpeg' || metadata.format === 'jpg') {
            await image
                .jpeg({ quality: quality, progressive: true })
                .toFile(outputPath);
        } else if (metadata.format === 'png') {
            await image
                .png({ compressionLevel: 9, progressive: true })
                .toFile(outputPath);
        } else if (metadata.format === 'webp') {
            await image
                .webp({ quality: quality })
                .toFile(outputPath);
        } else {
            // Convert to JPEG for other formats
            await image
                .jpeg({ quality: quality, progressive: true })
                .toFile(outputPath);
        }
        
        return true;
    } catch (error) {
        console.error('Error compressing image:', error);
        return false;
    }
};

// Create ZIP archive
const createZipArchive = async (filePath, outputPath) => {
    try {
        const zip = new AdmZip();
        const fileName = path.basename(filePath);
        zip.addLocalFile(filePath, '', fileName);
        zip.writeZip(outputPath);
        return true;
    } catch (error) {
        console.error('Error creating ZIP:', error);
        return false;
    }
};

// Background removal function using custom Python script
const removeBackground = async (inputPath, outputPath) => {
    return new Promise((resolve, reject) => {
        const scriptPath = path.join(__dirname, 'remove_bg.py');
        const bgRemover = spawn('python3', [scriptPath, inputPath, outputPath]);
        
        let output = '';
        let error = '';
        
        bgRemover.stdout.on('data', (data) => {
            output += data.toString();
        });
        
        bgRemover.stderr.on('data', (data) => {
            error += data.toString();
        });
        
        bgRemover.on('close', (code) => {
            if (code === 0 && output.includes('SUCCESS')) {
                resolve(true);
            } else {
                console.error('Background removal error:', error);
                // Fallback: copy original file with transparent background attempt
                fallbackBackgroundRemoval(inputPath, outputPath)
                    .then(resolve)
                    .catch(reject);
            }
        });
    });
};

// Fallback background removal using Sharp
const fallbackBackgroundRemoval = async (inputPath, outputPath) => {
    try {
        // Simple fallback: convert to PNG with some transparency
        await sharp(inputPath)
            .png({ 
                compressionLevel: 6,
                adaptiveFiltering: true,
                force: true
            })
            .toFile(outputPath);
        return true;
    } catch (error) {
        console.error('Fallback background removal failed:', error);
        return false;
    }
};

// Routes

// Serve main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: '✅ الموقع شغال' });
});

// Main processing endpoint
app.post('/api/process', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'لم يتم رفع أي ملف' });
        }
        
        const { service } = req.body;
        const inputPath = req.file.path;
        const originalStats = await getFileStats(inputPath);
        
        let outputPath;
        let outputFileName;
        let success = false;
        
        if (service === 'compress') {
            // Check if it's an image
            const isImage = req.file.mimetype.startsWith('image/');
            
            if (isImage) {
                // Compress image
                outputFileName = `compressed_${Date.now()}_${req.file.originalname}`;
                outputPath = path.join('./output', outputFileName);
                success = await compressImage(inputPath, outputPath, 70);
            } else {
                // Create ZIP archive
                outputFileName = `compressed_${Date.now()}_${path.parse(req.file.originalname).name}.zip`;
                outputPath = path.join('./output', outputFileName);
                success = await createZipArchive(inputPath, outputPath);
            }
        } else if (service === 'background') {
            // Remove background
            outputFileName = `no_bg_${Date.now()}_${path.parse(req.file.originalname).name}.png`;
            outputPath = path.join('./output', outputFileName);
            success = await removeBackground(inputPath, outputPath);
        } else {
            return res.status(400).json({ error: 'خدمة غير مدعومة' });
        }
        
        if (!success) {
            return res.status(500).json({ error: 'فشل في معالجة الملف' });
        }
        
        // Get output file stats
        const outputStats = await getFileStats(outputPath);
        
        // Clean up input file
        await fs.remove(inputPath);
        
        // Return result
        res.json({
            success: true,
            originalSize: originalStats.size,
            newSize: outputStats.size,
            downloadUrl: `/api/download/${outputFileName}`,
            fileName: outputFileName
        });
        
    } catch (error) {
        console.error('Processing error:', error);
        res.status(500).json({ error: 'حدث خطأ أثناء معالجة الملف' });
    }
});

// Download endpoint
app.get('/api/download/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join('./output', filename);
        
        // Check if file exists
        if (!await fs.pathExists(filePath)) {
            return res.status(404).json({ error: 'الملف غير موجود' });
        }
        
        // Set appropriate headers
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Type', 'application/octet-stream');
        
        // Stream file
        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);
        
        // Clean up file after download (optional)
        fileStream.on('end', () => {
            setTimeout(() => {
                fs.remove(filePath).catch(console.error);
            }, 60000); // Delete after 1 minute
        });
        
    } catch (error) {
        console.error('Download error:', error);
        res.status(500).json({ error: 'فشل في تحميل الملف' });
    }
});

// Get file info endpoint
app.get('/api/info/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join('./output', filename);
        
        if (!await fs.pathExists(filePath)) {
            return res.status(404).json({ error: 'الملف غير موجود' });
        }
        
        const stats = await getFileStats(filePath);
        
        res.json({
            filename: filename,
            size: stats.size,
            sizeFormatted: formatFileSize(stats.size),
            created: stats.created,
            modified: stats.modified
        });
        
    } catch (error) {
        console.error('Info error:', error);
        res.status(500).json({ error: 'فشل في الحصول على معلومات الملف' });
    }
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({ error: 'خطأ في الخادم' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'الصفحة غير موجودة' });
});

// Start server
const startServer = async () => {
    try {
        await ensureDirectories();
        
        app.listen(PORT, '0.0.0.0', () => {
            console.log(`✅ الموقع شغال على المنفذ ${PORT}`);
            console.log(`🌐 الرابط: http://localhost:${PORT}`);
            console.log(`📁 مجلد الرفع: ./uploads`);
            console.log(`📁 مجلد الإخراج: ./output`);
        });
    } catch (error) {
        console.error('فشل في بدء الخادم:', error);
        process.exit(1);
    }
};

// Handle graceful shutdown
process.on('SIGINT', async () => {
    console.log('\n🛑 جاري إيقاف الخادم...');
    
    // Clean up temporary files
    try {
        await fs.emptyDir('./uploads');
        await fs.emptyDir('./temp');
        console.log('✅ تم تنظيف الملفات المؤقتة');
    } catch (error) {
        console.error('خطأ في تنظيف الملفات:', error);
    }
    
    process.exit(0);
});

// Start the server
startServer();

