#!/usr/bin/env python3
import cv2
import numpy as np
import sys
import os
from PIL import Image

def remove_background_simple(input_path, output_path):
    """
    Remove background using simple color-based segmentation
    This is a basic implementation - for better results, use rembg or similar
    """
    try:
        # Read image
        img = cv2.imread(input_path)
        if img is None:
            raise ValueError("Could not read image")
        
        # Convert to RGB
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Create a simple mask based on edge detection and color
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply GaussianBlur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Apply threshold to get binary image
        _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Create mask
        mask = np.zeros(gray.shape, dtype=np.uint8)
        
        if contours:
            # Find the largest contour (assuming it's the main subject)
            largest_contour = max(contours, key=cv2.contourArea)
            cv2.fillPoly(mask, [largest_contour], 255)
        else:
            # If no contours found, use the center area
            h, w = gray.shape
            cv2.rectangle(mask, (w//4, h//4), (3*w//4, 3*h//4), 255, -1)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        
        # Apply Gaussian blur to soften edges
        mask = cv2.GaussianBlur(mask, (5, 5), 0)
        
        # Create RGBA image
        img_rgba = cv2.cvtColor(img, cv2.COLOR_BGR2RGBA)
        
        # Apply mask to alpha channel
        img_rgba[:, :, 3] = mask
        
        # Convert to PIL Image and save as PNG
        pil_img = Image.fromarray(img_rgba, 'RGBA')
        pil_img.save(output_path, 'PNG')
        
        return True
        
    except Exception as e:
        print(f"Error in remove_background_simple: {str(e)}")
        return False

def remove_background_grabcut(input_path, output_path):
    """
    Remove background using GrabCut algorithm
    """
    try:
        # Read image
        img = cv2.imread(input_path)
        if img is None:
            raise ValueError("Could not read image")
        
        height, width = img.shape[:2]
        
        # Create initial mask
        mask = np.zeros((height, width), np.uint8)
        
        # Define rectangle around the object (assuming object is in center)
        rect = (width//8, height//8, 6*width//8, 6*height//8)
        
        # Initialize background and foreground models
        bgd_model = np.zeros((1, 65), np.float64)
        fgd_model = np.zeros((1, 65), np.float64)
        
        # Apply GrabCut
        cv2.grabCut(img, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
        
        # Create final mask
        mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        
        # Apply morphological operations
        kernel = np.ones((3, 3), np.uint8)
        mask2 = cv2.morphologyEx(mask2, cv2.MORPH_CLOSE, kernel)
        mask2 = cv2.morphologyEx(mask2, cv2.MORPH_OPEN, kernel)
        
        # Apply Gaussian blur to soften edges
        mask2 = cv2.GaussianBlur(mask2, (3, 3), 0)
        
        # Create RGBA image
        img_rgba = cv2.cvtColor(img, cv2.COLOR_BGR2RGBA)
        
        # Apply mask to alpha channel
        img_rgba[:, :, 3] = mask2 * 255
        
        # Convert to PIL Image and save as PNG
        pil_img = Image.fromarray(img_rgba, 'RGBA')
        pil_img.save(output_path, 'PNG')
        
        return True
        
    except Exception as e:
        print(f"Error in remove_background_grabcut: {str(e)}")
        return False

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 remove_bg.py <input_path> <output_path>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    if not os.path.exists(input_path):
        print(f"Error: Input file {input_path} does not exist")
        sys.exit(1)
    
    # Try GrabCut first, fallback to simple method
    success = remove_background_grabcut(input_path, output_path)
    
    if not success:
        print("GrabCut failed, trying simple method...")
        success = remove_background_simple(input_path, output_path)
    
    if success:
        print("SUCCESS")
        sys.exit(0)
    else:
        print("ERROR: Failed to remove background")
        sys.exit(1)

if __name__ == "__main__":
    main()

