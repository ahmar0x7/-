let selectedService = null;
let selectedFile = null;

// DOM Elements
const serviceCards = document.querySelectorAll('.service-card');
const uploadSection = document.getElementById('uploadSection');
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const fileInfo = document.getElementById('fileInfo');
const processBtn = document.getElementById('processBtn');
const progressSection = document.getElementById('progressSection');
const resultSection = document.getElementById('resultSection');

// Service Selection
serviceCards.forEach(card => {
    card.addEventListener('click', () => {
        // Remove previous selection
        serviceCards.forEach(c => c.classList.remove('selected'));
        
        // Add selection to clicked card
        card.classList.add('selected');
        selectedService = card.dataset.service;
        
        // Show upload section
        uploadSection.style.display = 'block';
        uploadSection.scrollIntoView({ behavior: 'smooth' });
        
        // Update upload area text based on service
        updateUploadAreaText();
    });
});

function updateUploadAreaText() {
    const uploadIcon = uploadArea.querySelector('.upload-icon i');
    const uploadTitle = uploadArea.querySelector('h3');
    const uploadHint = uploadArea.querySelector('.upload-hint');
    
    if (selectedService === 'compress') {
        uploadIcon.className = 'fas fa-compress-alt';
        uploadTitle.textContent = 'اسحب الملفات أو الصور هنا للضغط';
        uploadHint.textContent = 'يدعم جميع أنواع الملفات والصور (JPG, PNG, PDF, ZIP, إلخ)';
        fileInput.accept = '*/*';
    } else if (selectedService === 'background') {
        uploadIcon.className = 'fas fa-image';
        uploadTitle.textContent = 'اسحب الصورة هنا لحذف الخلفية';
        uploadHint.textContent = 'يدعم صور JPG, PNG, WEBP';
        fileInput.accept = 'image/*';
    }
}

// File Upload Handling
uploadArea.addEventListener('click', () => {
    fileInput.click();
});

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('dragover');
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('dragover');
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFileSelection(files[0]);
    }
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleFileSelection(e.target.files[0]);
    }
});

function handleFileSelection(file) {
    selectedFile = file;
    
    // Validate file type based on service
    if (selectedService === 'background' && !file.type.startsWith('image/')) {
        alert('يرجى اختيار ملف صورة لخدمة حذف الخلفية');
        return;
    }
    
    // Show file info
    displayFileInfo(file);
    
    // Hide upload area and show file info
    uploadArea.style.display = 'none';
    fileInfo.style.display = 'flex';
}

function displayFileInfo(file) {
    const fileName = fileInfo.querySelector('.file-name');
    const fileSize = fileInfo.querySelector('.file-size');
    const fileIcon = fileInfo.querySelector('.file-icon i');
    
    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    
    // Set appropriate icon based on file type
    if (file.type.startsWith('image/')) {
        fileIcon.className = 'fas fa-image';
    } else if (file.type === 'application/pdf') {
        fileIcon.className = 'fas fa-file-pdf';
    } else if (file.type.includes('zip') || file.type.includes('rar')) {
        fileIcon.className = 'fas fa-file-archive';
    } else {
        fileIcon.className = 'fas fa-file';
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 بايت';
    
    const k = 1024;
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Process File
processBtn.addEventListener('click', () => {
    if (!selectedFile || !selectedService) {
        alert('يرجى اختيار الخدمة والملف أولاً');
        return;
    }
    
    processFile();
});

async function processFile() {
    // Hide file info and show progress
    fileInfo.style.display = 'none';
    progressSection.style.display = 'block';
    progressSection.scrollIntoView({ behavior: 'smooth' });
    
    // Simulate progress
    simulateProgress();
    
    try {
        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('service', selectedService);
        
        const response = await fetch('/api/process', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('فشل في معالجة الملف');
        }
        
        const result = await response.json();
        
        // Hide progress and show result
        progressSection.style.display = 'none';
        showResult(result);
        
    } catch (error) {
        console.error('Error:', error);
        alert('حدث خطأ أثناء معالجة الملف: ' + error.message);
        
        // Reset to file info
        progressSection.style.display = 'none';
        fileInfo.style.display = 'flex';
    }
}

function simulateProgress() {
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        
        progressFill.style.width = progress + '%';
        
        if (progress < 30) {
            progressText.textContent = 'جاري تحليل الملف...';
        } else if (progress < 60) {
            progressText.textContent = 'جاري المعالجة...';
        } else {
            progressText.textContent = 'جاري إنهاء العملية...';
        }
        
        if (progress >= 90) {
            clearInterval(interval);
        }
    }, 200);
}

function showResult(result) {
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth' });
    
    // Update result information
    document.getElementById('originalSize').textContent = formatFileSize(result.originalSize);
    document.getElementById('newSize').textContent = formatFileSize(result.newSize);
    
    const compressionRatio = ((result.originalSize - result.newSize) / result.originalSize * 100).toFixed(1);
    document.getElementById('compressionRatio').textContent = compressionRatio + '%';
    
    // Set up download button
    const downloadBtn = document.getElementById('downloadBtn');
    downloadBtn.onclick = () => {
        window.open(result.downloadUrl, '_blank');
    };
}

// Reset functionality
function resetForm() {
    selectedService = null;
    selectedFile = null;
    
    // Reset UI
    serviceCards.forEach(card => card.classList.remove('selected'));
    uploadSection.style.display = 'none';
    uploadArea.style.display = 'block';
    fileInfo.style.display = 'none';
    progressSection.style.display = 'none';
    resultSection.style.display = 'none';
    
    // Reset file input
    fileInput.value = '';
}

// Add some interactive effects
document.addEventListener('DOMContentLoaded', () => {
    // Add entrance animations
    const elements = document.querySelectorAll('.service-card, .header');
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            el.style.transition = 'all 0.6s ease';
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 100);
    });
});

